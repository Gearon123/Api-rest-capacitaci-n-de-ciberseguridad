package com.udb.ciberseguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiberseguridadApplication {
    public static void main(String[] args) {
        SpringApplication.run(CiberseguridadApplication.class, args);
    }
}