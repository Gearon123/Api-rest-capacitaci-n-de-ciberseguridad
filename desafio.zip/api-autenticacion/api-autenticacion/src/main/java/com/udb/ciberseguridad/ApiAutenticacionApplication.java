package com.udb.ciberseguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAutenticacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAutenticacionApplication.class, args);
	}

}
